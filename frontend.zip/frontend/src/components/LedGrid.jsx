import React from 'react';
import LedIndicator from './LedIndicator';
import './LedGrid.css';

const LedGrid = ({ 
    clients, 
    leds, 
    alarmingClientId, 
    activeClientId, 
    // Sound props from App.jsx
    soundFiles, 
    globalSound, 
    onSetGlobalSound,
    onPlayTestSound
}) => {

  const handleSoundChange = (e) => {
    onSetGlobalSound(e.target.value);
  };

  return (
    <div className="card">
      <div className="card-header">
        <h3>Client LED Indicators</h3>
        <div className="alarm-controls">
          <select
            value={globalSound}
            onChange={handleSoundChange}
          >
            {soundFiles.map((sound) => (
              <option key={sound} value={sound}>
                {sound}
              </option>
            ))}
          </select>

          <button onClick={onPlayTestSound}>
            Play/Stop Test
          </button>
        </div>
      </div>

      {clients.length > 0 ? (
        <div className="led-grid-container">
          {clients.map(client => (
            <div
              key={client.id}
              className={`led-item ${client.id === alarmingClientId ? 'alarming' : ''}`}
            >
              <LedIndicator state={client.led_state || 'off'} />
              <div className="led-label">
                <span className="led-name">{client.name}</span>
                <span className="led-ip">{client.ip}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="no-clients-message">No devices registered.</p>
      )}
    </div>
  );
};

export default LedGrid;
