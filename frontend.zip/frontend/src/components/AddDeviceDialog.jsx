import React, { useState } from 'react';
import './AddDeviceDialog.css';

const AddDeviceDialog = ({ onClose, onDeviceAdded }) => {
    const [name, setName] = useState('');
    const [ip, setIp] = useState('');
    const [mac, setMac] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!name || !ip) {
            setError('Device Name and IP Address are required.');
            return;
        }

        try {
            const response = await fetch('http://localhost:5000/api/devices', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, ip, mac }),
            });

            if (response.ok) {
                const newDevice = await response.json();
                onDeviceAdded(newDevice);
                onClose();
            } else {
                const errorData = await response.json();
                setError(errorData.error || 'Failed to add device.');
            }
        } catch (err) {
            setError('An error occurred while communicating with the server.');
        }
    };

    return (
        <div className="dialog-backdrop">
            <div className="dialog-content">
                <h2>Add New Device</h2>
                {error && <p className="error-message">{error}</p>}
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="name">Device Name</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="ip">IP Address</label>
                        <input
                            type="text"
                            id="ip"
                            value={ip}
                            onChange={(e) => setIp(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="mac">MAC Address (Optional)</label>
                        <input
                            type="text"
                            id="mac"
                            value={mac}
                            onChange={(e) => setMac(e.target.value)}
                        />
                    </div>
                    <div className="form-actions">
                        <button type="submit" className="btn-primary">Save Device</button>
                        <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddDeviceDialog;
